#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "cus_msg__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__cus_msg__msg__CustomMsg() -> *const std::ffi::c_void;
}

#[link(name = "cus_msg__rosidl_generator_c")]
extern "C" {
    fn cus_msg__msg__CustomMsg__init(msg: *mut CustomMsg) -> bool;
    fn cus_msg__msg__CustomMsg__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CustomMsg>, size: usize) -> bool;
    fn cus_msg__msg__CustomMsg__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CustomMsg>);
    fn cus_msg__msg__CustomMsg__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CustomMsg>, out_seq: *mut rosidl_runtime_rs::Sequence<CustomMsg>) -> bool;
}

// Corresponds to cus_msg__msg__CustomMsg
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CustomMsg {

    // This member is not documented.
    #[allow(missing_docs)]
    pub v: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub rad: f64,

}



impl Default for CustomMsg {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !cus_msg__msg__CustomMsg__init(&mut msg as *mut _) {
        panic!("Call to cus_msg__msg__CustomMsg__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CustomMsg {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { cus_msg__msg__CustomMsg__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { cus_msg__msg__CustomMsg__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { cus_msg__msg__CustomMsg__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CustomMsg {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CustomMsg where Self: Sized {
  const TYPE_NAME: &'static str = "cus_msg/msg/CustomMsg";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__cus_msg__msg__CustomMsg() }
  }
}


