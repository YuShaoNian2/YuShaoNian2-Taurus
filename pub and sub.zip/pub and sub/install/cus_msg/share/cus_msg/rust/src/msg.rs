#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to cus_msg__msg__CustomMsg

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CustomMsg {

    // This member is not documented.
    #[allow(missing_docs)]
    pub v: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub rad: f64,

}



impl Default for CustomMsg {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::CustomMsg::default())
  }
}

impl rosidl_runtime_rs::Message for CustomMsg {
  type RmwMsg = super::msg::rmw::CustomMsg;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        v: msg.v,
        rad: msg.rad,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      v: msg.v,
      rad: msg.rad,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      v: msg.v,
      rad: msg.rad,
    }
  }
}


