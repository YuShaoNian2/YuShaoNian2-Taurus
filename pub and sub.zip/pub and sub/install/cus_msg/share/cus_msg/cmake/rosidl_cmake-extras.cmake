# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(cus_msg_IDL_FILES "msg/CustomMsg.idl")
set(cus_msg_INTERFACE_FILES "msg/CustomMsg.msg")
