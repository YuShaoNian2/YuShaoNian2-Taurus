# generated from rosidl_cmake/cmake/rosidl_cmake_aggregate_target-extras.cmake.in

# Create a convenience aggregate target cus_msg::cus_msg
# that links all generated interface targets, so downstream packages can use
# a single modern CMake target name instead of ${cus_msg_TARGETS}.
if(cus_msg_TARGETS AND NOT TARGET cus_msg::cus_msg)
  add_library(cus_msg::cus_msg INTERFACE IMPORTED)
  set_target_properties(cus_msg::cus_msg PROPERTIES
    INTERFACE_LINK_LIBRARIES "${cus_msg_TARGETS}")
endif()
