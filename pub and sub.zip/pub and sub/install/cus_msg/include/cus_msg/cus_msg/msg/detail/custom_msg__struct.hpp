// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "cus_msg/msg/custom_msg.hpp"


#ifndef CUS_MSG__MSG__DETAIL__CUSTOM_MSG__STRUCT_HPP_
#define CUS_MSG__MSG__DETAIL__CUSTOM_MSG__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__cus_msg__msg__CustomMsg __attribute__((deprecated))
#else
# define DEPRECATED__cus_msg__msg__CustomMsg __declspec(deprecated)
#endif

namespace cus_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CustomMsg_
{
  using Type = CustomMsg_<ContainerAllocator>;

  explicit CustomMsg_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->v = 0l;
      this->rad = 0.0;
    }
  }

  explicit CustomMsg_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->v = 0l;
      this->rad = 0.0;
    }
  }

  // field types and members
  using _v_type =
    int32_t;
  _v_type v;
  using _rad_type =
    double;
  _rad_type rad;

  // setters for named parameter idiom
  Type & set__v(
    const int32_t & _arg)
  {
    this->v = _arg;
    return *this;
  }
  Type & set__rad(
    const double & _arg)
  {
    this->rad = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    cus_msg::msg::CustomMsg_<ContainerAllocator> *;
  using ConstRawPtr =
    const cus_msg::msg::CustomMsg_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<cus_msg::msg::CustomMsg_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<cus_msg::msg::CustomMsg_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      cus_msg::msg::CustomMsg_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<cus_msg::msg::CustomMsg_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      cus_msg::msg::CustomMsg_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<cus_msg::msg::CustomMsg_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<cus_msg::msg::CustomMsg_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<cus_msg::msg::CustomMsg_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__cus_msg__msg__CustomMsg
    std::shared_ptr<cus_msg::msg::CustomMsg_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__cus_msg__msg__CustomMsg
    std::shared_ptr<cus_msg::msg::CustomMsg_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CustomMsg_ & other) const
  {
    if (this->v != other.v) {
      return false;
    }
    if (this->rad != other.rad) {
      return false;
    }
    return true;
  }
  bool operator!=(const CustomMsg_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CustomMsg_

// alias to use template instance with default allocator
using CustomMsg =
  cus_msg::msg::CustomMsg_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace cus_msg

#endif  // CUS_MSG__MSG__DETAIL__CUSTOM_MSG__STRUCT_HPP_
