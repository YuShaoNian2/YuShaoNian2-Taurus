// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice
#ifndef CUS_MSG__MSG__DETAIL__CUSTOM_MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define CUS_MSG__MSG__DETAIL__CUSTOM_MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "cus_msg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "cus_msg/msg/detail/custom_msg__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cus_msg
bool cdr_serialize_cus_msg__msg__CustomMsg(
  const cus_msg__msg__CustomMsg * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cus_msg
bool cdr_deserialize_cus_msg__msg__CustomMsg(
  eprosima::fastcdr::Cdr &,
  cus_msg__msg__CustomMsg * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cus_msg
size_t get_serialized_size_cus_msg__msg__CustomMsg(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cus_msg
size_t max_serialized_size_cus_msg__msg__CustomMsg(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cus_msg
bool cdr_serialize_key_cus_msg__msg__CustomMsg(
  const cus_msg__msg__CustomMsg * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cus_msg
size_t get_serialized_size_key_cus_msg__msg__CustomMsg(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cus_msg
size_t max_serialized_size_key_cus_msg__msg__CustomMsg(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_cus_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, cus_msg, msg, CustomMsg)();

#ifdef __cplusplus
}
#endif

#endif  // CUS_MSG__MSG__DETAIL__CUSTOM_MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
