// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "cus_msg/msg/detail/custom_msg__functions.h"
#include "cus_msg/msg/detail/custom_msg__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace cus_msg
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void CustomMsg_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) cus_msg::msg::CustomMsg(_init);
}

void CustomMsg_fini_function(void * message_memory)
{
  auto typed_message = static_cast<cus_msg::msg::CustomMsg *>(message_memory);
  typed_message->~CustomMsg();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember CustomMsg_message_member_array[2] = {
  {
    "v",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cus_msg::msg::CustomMsg, v),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "rad",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cus_msg::msg::CustomMsg, rad),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers CustomMsg_message_members = {
  "cus_msg::msg",  // message namespace
  "CustomMsg",  // message name
  2,  // number of fields
  sizeof(cus_msg::msg::CustomMsg),
  false,  // has_any_key_member_
  CustomMsg_message_member_array,  // message members
  CustomMsg_init_function,  // function to initialize message memory (memory has to be allocated)
  CustomMsg_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t CustomMsg_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &CustomMsg_message_members,
  get_message_typesupport_handle_function,
  &cus_msg__msg__CustomMsg__get_type_hash,
  &cus_msg__msg__CustomMsg__get_type_description,
  &cus_msg__msg__CustomMsg__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace cus_msg


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<cus_msg::msg::CustomMsg>()
{
  return &::cus_msg::msg::rosidl_typesupport_introspection_cpp::CustomMsg_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, cus_msg, msg, CustomMsg)() {
  return &::cus_msg::msg::rosidl_typesupport_introspection_cpp::CustomMsg_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
