// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "cus_msg/msg/custom_msg.hpp"


#ifndef CUS_MSG__MSG__DETAIL__CUSTOM_MSG__BUILDER_HPP_
#define CUS_MSG__MSG__DETAIL__CUSTOM_MSG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "cus_msg/msg/detail/custom_msg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace cus_msg
{

namespace msg
{

namespace builder
{

class Init_CustomMsg_rad
{
public:
  explicit Init_CustomMsg_rad(::cus_msg::msg::CustomMsg & msg)
  : msg_(msg)
  {}
  ::cus_msg::msg::CustomMsg rad(::cus_msg::msg::CustomMsg::_rad_type arg)
  {
    msg_.rad = std::move(arg);
    return std::move(msg_);
  }

private:
  ::cus_msg::msg::CustomMsg msg_;
};

class Init_CustomMsg_v
{
public:
  Init_CustomMsg_v()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CustomMsg_rad v(::cus_msg::msg::CustomMsg::_v_type arg)
  {
    msg_.v = std::move(arg);
    return Init_CustomMsg_rad(msg_);
  }

private:
  ::cus_msg::msg::CustomMsg msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::cus_msg::msg::CustomMsg>()
{
  return cus_msg::msg::builder::Init_CustomMsg_v();
}

}  // namespace cus_msg

#endif  // CUS_MSG__MSG__DETAIL__CUSTOM_MSG__BUILDER_HPP_
