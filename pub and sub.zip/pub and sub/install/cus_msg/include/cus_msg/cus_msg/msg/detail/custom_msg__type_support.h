// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "cus_msg/msg/custom_msg.h"


#ifndef CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TYPE_SUPPORT_H_
#define CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "cus_msg/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_cus_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  cus_msg,
  msg,
  CustomMsg
)(void);

#ifdef __cplusplus
}
#endif

#endif  // CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TYPE_SUPPORT_H_
