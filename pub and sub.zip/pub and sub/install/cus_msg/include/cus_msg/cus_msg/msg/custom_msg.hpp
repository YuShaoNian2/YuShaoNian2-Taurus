// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUS_MSG__MSG__CUSTOM_MSG_HPP_
#define CUS_MSG__MSG__CUSTOM_MSG_HPP_

#include "cus_msg/msg/detail/custom_msg__struct.hpp"
#include "cus_msg/msg/detail/custom_msg__builder.hpp"
#include "cus_msg/msg/detail/custom_msg__traits.hpp"
#include "cus_msg/msg/detail/custom_msg__type_support.hpp"

#endif  // CUS_MSG__MSG__CUSTOM_MSG_HPP_
