// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice
#include "cus_msg/msg/detail/custom_msg__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
cus_msg__msg__CustomMsg__init(cus_msg__msg__CustomMsg * msg)
{
  if (!msg) {
    return false;
  }
  // v
  // rad
  return true;
}

void
cus_msg__msg__CustomMsg__fini(cus_msg__msg__CustomMsg * msg)
{
  if (!msg) {
    return;
  }
  // v
  // rad
}

bool
cus_msg__msg__CustomMsg__are_equal(const cus_msg__msg__CustomMsg * lhs, const cus_msg__msg__CustomMsg * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // v
  if (lhs->v != rhs->v) {
    return false;
  }
  // rad
  if (lhs->rad != rhs->rad) {
    return false;
  }
  return true;
}

bool
cus_msg__msg__CustomMsg__copy(
  const cus_msg__msg__CustomMsg * input,
  cus_msg__msg__CustomMsg * output)
{
  if (!input || !output) {
    return false;
  }
  // v
  output->v = input->v;
  // rad
  output->rad = input->rad;
  return true;
}

cus_msg__msg__CustomMsg *
cus_msg__msg__CustomMsg__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cus_msg__msg__CustomMsg * msg = (cus_msg__msg__CustomMsg *)allocator.allocate(sizeof(cus_msg__msg__CustomMsg), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cus_msg__msg__CustomMsg));
  bool success = cus_msg__msg__CustomMsg__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cus_msg__msg__CustomMsg__destroy(cus_msg__msg__CustomMsg * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cus_msg__msg__CustomMsg__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cus_msg__msg__CustomMsg__Sequence__init(cus_msg__msg__CustomMsg__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cus_msg__msg__CustomMsg * data = NULL;

  if (size) {
    if (size > SIZE_MAX / sizeof(cus_msg__msg__CustomMsg)) {
      return false;
    }
    data = (cus_msg__msg__CustomMsg *)allocator.zero_allocate(size, sizeof(cus_msg__msg__CustomMsg), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cus_msg__msg__CustomMsg__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cus_msg__msg__CustomMsg__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cus_msg__msg__CustomMsg__Sequence__fini(cus_msg__msg__CustomMsg__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cus_msg__msg__CustomMsg__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cus_msg__msg__CustomMsg__Sequence *
cus_msg__msg__CustomMsg__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cus_msg__msg__CustomMsg__Sequence * array = (cus_msg__msg__CustomMsg__Sequence *)allocator.allocate(sizeof(cus_msg__msg__CustomMsg__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cus_msg__msg__CustomMsg__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cus_msg__msg__CustomMsg__Sequence__destroy(cus_msg__msg__CustomMsg__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cus_msg__msg__CustomMsg__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cus_msg__msg__CustomMsg__Sequence__are_equal(const cus_msg__msg__CustomMsg__Sequence * lhs, const cus_msg__msg__CustomMsg__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cus_msg__msg__CustomMsg__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cus_msg__msg__CustomMsg__Sequence__copy(
  const cus_msg__msg__CustomMsg__Sequence * input,
  cus_msg__msg__CustomMsg__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    if (input->size > SIZE_MAX / sizeof(cus_msg__msg__CustomMsg)) {
      return false;
    }
    const size_t allocation_size =
      input->size * sizeof(cus_msg__msg__CustomMsg);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cus_msg__msg__CustomMsg * data =
      (cus_msg__msg__CustomMsg *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cus_msg__msg__CustomMsg__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cus_msg__msg__CustomMsg__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cus_msg__msg__CustomMsg__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
