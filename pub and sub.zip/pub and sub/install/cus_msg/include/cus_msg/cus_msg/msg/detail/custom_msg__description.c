// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

#include "cus_msg/msg/detail/custom_msg__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_cus_msg
const rosidl_type_hash_t *
cus_msg__msg__CustomMsg__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x20, 0x52, 0x28, 0x47, 0x3d, 0x01, 0xcf, 0x4c,
      0x4c, 0xcc, 0x21, 0x36, 0x85, 0x1c, 0x27, 0xf2,
      0x9f, 0x27, 0x8b, 0x33, 0x1a, 0xa8, 0xb6, 0xe7,
      0x8d, 0xe8, 0x19, 0x99, 0x99, 0x74, 0x77, 0xc0,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char cus_msg__msg__CustomMsg__TYPE_NAME[] = "cus_msg/msg/CustomMsg";

// Define type names, field names, and default values
static char cus_msg__msg__CustomMsg__FIELD_NAME__v[] = "v";
static char cus_msg__msg__CustomMsg__FIELD_NAME__rad[] = "rad";

static rosidl_runtime_c__type_description__Field cus_msg__msg__CustomMsg__FIELDS[] = {
  {
    {cus_msg__msg__CustomMsg__FIELD_NAME__v, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {cus_msg__msg__CustomMsg__FIELD_NAME__rad, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
cus_msg__msg__CustomMsg__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {cus_msg__msg__CustomMsg__TYPE_NAME, 21, 21},
      {cus_msg__msg__CustomMsg__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "int32 v\n"
  "float64 rad";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
cus_msg__msg__CustomMsg__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {cus_msg__msg__CustomMsg__TYPE_NAME, 21, 21},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 19, 19},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
cus_msg__msg__CustomMsg__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *cus_msg__msg__CustomMsg__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
