// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

#ifndef CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TYPE_SUPPORT_HPP_
#define CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "cus_msg/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_cus_msg
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  cus_msg,
  msg,
  CustomMsg
)();
#ifdef __cplusplus
}
#endif

#endif  // CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TYPE_SUPPORT_HPP_
