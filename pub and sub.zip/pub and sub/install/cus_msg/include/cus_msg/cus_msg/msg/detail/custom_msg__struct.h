// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "cus_msg/msg/custom_msg.h"


#ifndef CUS_MSG__MSG__DETAIL__CUSTOM_MSG__STRUCT_H_
#define CUS_MSG__MSG__DETAIL__CUSTOM_MSG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/CustomMsg in the package cus_msg.
typedef struct cus_msg__msg__CustomMsg
{
  int32_t v;
  double rad;
} cus_msg__msg__CustomMsg;

// Struct for a sequence of cus_msg__msg__CustomMsg.
typedef struct cus_msg__msg__CustomMsg__Sequence
{
  cus_msg__msg__CustomMsg * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} cus_msg__msg__CustomMsg__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUS_MSG__MSG__DETAIL__CUSTOM_MSG__STRUCT_H_
