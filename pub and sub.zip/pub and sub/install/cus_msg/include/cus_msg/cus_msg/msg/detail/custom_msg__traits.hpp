// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "cus_msg/msg/custom_msg.hpp"


#ifndef CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TRAITS_HPP_
#define CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "cus_msg/msg/detail/custom_msg__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace cus_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const CustomMsg & msg,
  std::ostream & out)
{
  out << "{";
  // member: v
  {
    out << "v: ";
    rosidl_generator_traits::value_to_yaml(msg.v, out);
    out << ", ";
  }

  // member: rad
  {
    out << "rad: ";
    rosidl_generator_traits::value_to_yaml(msg.rad, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CustomMsg & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: v
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "v: ";
    rosidl_generator_traits::value_to_yaml(msg.v, out);
    out << "\n";
  }

  // member: rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rad: ";
    rosidl_generator_traits::value_to_yaml(msg.rad, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CustomMsg & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace cus_msg

namespace rosidl_generator_traits
{

[[deprecated("use cus_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const cus_msg::msg::CustomMsg & msg,
  std::ostream & out, size_t indentation = 0)
{
  cus_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use cus_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const cus_msg::msg::CustomMsg & msg)
{
  return cus_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<cus_msg::msg::CustomMsg>()
{
  return "cus_msg::msg::CustomMsg";
}

template<>
inline const char * name<cus_msg::msg::CustomMsg>()
{
  return "cus_msg/msg/CustomMsg";
}

template<>
struct has_fixed_size<cus_msg::msg::CustomMsg>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<cus_msg::msg::CustomMsg>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<cus_msg::msg::CustomMsg>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CUS_MSG__MSG__DETAIL__CUSTOM_MSG__TRAITS_HPP_
