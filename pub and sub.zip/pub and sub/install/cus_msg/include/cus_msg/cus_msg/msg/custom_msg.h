// generated from rosidl_generator_c/resource/idl.h.em
// with input from cus_msg:msg/CustomMsg.idl
// generated code does not contain a copyright notice

#ifndef CUS_MSG__MSG__CUSTOM_MSG_H_
#define CUS_MSG__MSG__CUSTOM_MSG_H_

#include "cus_msg/msg/detail/custom_msg__struct.h"
#include "cus_msg/msg/detail/custom_msg__functions.h"
#include "cus_msg/msg/detail/custom_msg__type_support.h"

#endif  // CUS_MSG__MSG__CUSTOM_MSG_H_
